<div class="bidder_content">
    <div class="title">
        <span>Bid: </span><span>Duration: </span><span>100% Positive</span>
    </div>
    <div class="note">
        <p><b>Note:</b> Not available at the moment</p>
    </div>
</div>