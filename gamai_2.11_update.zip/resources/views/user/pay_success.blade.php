
<div class="pay-success" >
    <h3>Hi,{{$user->username}}</h3>

    <h5>You upgraded your membership to {{$membership->membership_status}} successfully</h5>

</div>
